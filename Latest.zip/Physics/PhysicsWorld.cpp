#include "PhysicsWorld.hpp"

using namespace P6;

void PhysicsWorld::AddParticle(P6Particle* toAdd){
	Particles.push_back(toAdd);

	this->forceRegistry.Add(toAdd, &this->Gravity);
}

void PhysicsWorld::AddContact(P6Particle* p1, P6Particle* p2, float restitution, MyVector contactNormal){
	ParticleContact* toAdd = new ParticleContact();

	// assign the needed variables and values
	toAdd->particles[0] = p1;
	toAdd->particles[1] = p2;
	toAdd->restitution = restitution;
	toAdd->contactNormal = contactNormal;

	this->Contacts.push_back(toAdd);
}

void PhysicsWorld::Update(float time){
	//update the list first before calling
	//the updates for the particles

	this->UpdateParticleList();

	forceRegistry.UpdateForces(time);

	for (std::list<P6Particle*>::iterator p = this->Particles.begin();
		//continue looping until the end of the list
			p != Particles.end(); 
		//move to the next particle	
			p++) {

		//call the particle's update
		(*p)->Update(time);

	}

	this->GenerateContacts();

	// only call resolve contacts
	// when there are contacts
	if (this->Contacts.size() > 0) {
		this->contactResolver.ResolveContacts(this->Contacts, time);
	}
}

void PhysicsWorld::UpdateParticleList(){
	//remove all the partices in the list that
	//return true to the function below

	Particles.remove_if(
		//check aALL the particles in this list
		//if their isDestroyed flag is true
		[](P6Particle* p) {
			return p->IsDestroyed();
		}
	);
}

void PhysicsWorld::GenerateContacts() {
	// clear the current list of contacts
	this->Contacts.clear();

	//iterate throught the list of links
	for (std::list<ParticleLink*>::iterator i = Links.begin();
		i != Links.end();
		i++) {
		// try and get contact for the link
		ParticleContact* contact = (*i)->GetContact();
		// if contacts exists
		// push it to the list
		if (contact != nullptr) {
			this->Contacts.push_back(contact);
		}
	}
}
