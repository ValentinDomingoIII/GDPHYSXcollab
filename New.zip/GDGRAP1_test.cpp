#include <iostream>
#include <string>
#include <chrono>
#include <vector>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

#include "Physics/MyVector.hpp"
#include "Physics/PhysicsWorld.hpp"
#include "Physics/P6Particle.hpp"
#include "Shaders/Shader.hpp"
#include "Object.hpp"
#include "Physics/RenderParticle.hpp"
#include "Physics/DragForceGenerator.hpp"

using namespace std::chrono_literals;
//THis is going tobe time between frames
constexpr std::chrono::nanoseconds timestep(16ms);

int main(void)
{
    float WINDOW_HEIGHT = 700.0f;
    float WINDOW_WIDTH = 700.0f;

    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "PC01 Bumanglag, Nikos Railey", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL();

    //////////////////////////////////////////////////////////////////////////
    GLuint VAO;
    GLuint VBO;
    GLuint EBO;
    std::string path = "3D/bola.obj";

    std::vector<tinyobj::shape_t>shapes;
    std::vector<tinyobj::material_t> material;

    tinyobj::attrib_t attributes;
    std::vector<GLuint> mesh_indices;

    std::string warning;
    std::string error;

    bool success = tinyobj::LoadObj(
        &attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    for (int i = 0; i < shapes[0].mesh.indices.size(); i++) {
        mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
    }

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    //Currently Editing VAO = null
    glBindVertexArray(VAO);
    //Currently editing VBO = null
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    //Currently editing VBO = VBO

    glBufferData(GL_ARRAY_BUFFER,
        sizeof(GL_FLOAT) * attributes.vertices.size(),//bytes
        attributes.vertices.data(),// array
        GL_STATIC_DRAW);

    glVertexAttribPointer(
        0,
        3, // x y z
        GL_FLOAT,
        GL_FALSE,
        3 * sizeof(float),
        (void*)0
    );

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
        sizeof(GLuint) * mesh_indices.size(),
        mesh_indices.data(),
        GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    /////////////////////////////////////////////////////////////////////////
    //orthographic
    //adjusted so that scale is 1px = 1m
    
    glm::mat4 projectionMatrix = glm::ortho(
        -WINDOW_WIDTH / 2.f, //left
        WINDOW_WIDTH / 2.f, //right
        -WINDOW_HEIGHT / 2.f, //bot
        WINDOW_HEIGHT / 2.f, //top
        -400.f, //z near
        400.f);  //z far

    ///////////////////////////////////////////////////////////////////////////////////////////
    P6::MyVector center(0, 0, 0);

    P6::P6Particle particle;
    P6::MyVector particlePos1(-300,0,0);
    particle.position = particlePos1;
    particle.mass = 1.f;          //1KG
    particle.AddForce(P6::MyVector(1000, 0, 0));  //(0,0,0) KG m/s^2

    P6::PhysicsWorld pWorld = P6::PhysicsWorld();

    P6::DragForceGenerator drag = P6::DragForceGenerator(0.f, 0.f);
    pWorld.forceRegistry.Add(&particle, &drag);

    pWorld.AddParticle(&particle);

    using clock = std::chrono::high_resolution_clock;
    auto curr_time = clock::now();
    auto prev_time = curr_time;
    std::chrono::nanoseconds curr_ns(0);
    std::chrono::nanoseconds stop(0);

    ///////////////////////////////////////////////////////////////////////////////////////////
    GLfloat red[] = { 1.0f, 0.0f, 0.0f, 1.0f };
    Object obj("Red", red, projectionMatrix);
    obj.scale_x = 10.f;
    obj.scale_y = 10.f;
    obj.scale_z = 10.f;

    RenderParticle p1 = RenderParticle(&particle, &obj);

    std::vector<RenderParticle*> vecRenderParticle;

    vecRenderParticle.push_back(&p1);    

    float TimeBeforeHittingCenter = 0.f;

    int numPushed = 4;

    while (!glfwWindowShouldClose(window))
    {
        //Get the current time
        curr_time = clock::now();
        //check the duration in between the last iteration
        auto dur = std::chrono::duration_cast<std::chrono::nanoseconds> (curr_time - prev_time);
        //set prev with the current for the next iteration
        prev_time = curr_time;

        curr_ns += dur;
        stop += dur;

        if (curr_ns >= timestep)
        {
            auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(curr_ns);
            auto stop1 = std::chrono::duration_cast<std::chrono::milliseconds>(stop);
            //std::cout << "MS:" << (float)ms.count() << "\n";
            //reset
            curr_ns -= timestep;

            //convert ms to seconds
            pWorld.Update((float)ms.count() / 1000);

            TimeBeforeHittingCenter = (float)stop1.count() / 1000;
        }

        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT);

        int i = 0;

        for (RenderParticle* particle : vecRenderParticle) {
            particle->Draw();

            glBindVertexArray(VAO);
            glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
        glfwPollEvents();
    }
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    char a;

    std::cout << "Enter any character to exit. . ." << std::endl;
    std::cin >> a;
    glfwTerminate();
    return 0;
}
