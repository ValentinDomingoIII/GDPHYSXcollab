#include <iostream>
#include <string>
#include <chrono>
#include <vector>
#include <random>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

#include "Physics/MyVector.hpp"
#include "Physics/P6Particle.hpp"
#include "Physics/PhysicsWorld.hpp"
#include "Physics/RenderParticle.hpp"
#include "Physics/ParticleContact.hpp"
#include "Physics/DragForceGenerator.hpp"
#include "Physics/Springs/AnchoredSpring.hpp"
#include "Physics/Springs/ParticleSpring.hpp"
#include "Physics/Springs/Bungee.hpp"
#include "Physics/Springs/Chain.hpp"
#include "Physics/Links/Rods.hpp"
#include "Shaders/Shader.hpp"
#include "RenderLine.hpp"
#include "Object.hpp"

using namespace P6;

#define WINDOW_HEIGHT 800.f
#define WINDOW_WIDTH 800.f

using namespace std::chrono_literals;

// This is going to be the time between frames
constexpr std::chrono::nanoseconds timestep(16ms);

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "Quiz Nikos Railey Bumanglag", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL();

    //////////////////////////////////////////////////////////////////////////
    GLuint VAO;
    GLuint VBO;
    GLuint EBO;
    std::string path = "3D/sphere.obj";

    std::vector<tinyobj::shape_t> shapes;
    std::vector<tinyobj::material_t> material;

    tinyobj::attrib_t attributes;
    std::vector<GLuint> mesh_indices;

    std::string warning;
    std::string error;

    bool success = tinyobj::LoadObj(
        &attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    for (int i = 0; i < shapes[0].mesh.indices.size(); i++) {
        mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
    }

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(GL_FLOAT) * attributes.vertices.size(), attributes.vertices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint) * mesh_indices.size(), mesh_indices.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    /////////////////////////////////////////////////////////////////////////

    Shader* shader = new Shader("Shaders/sample.vert", "Shaders/sample.frag");

    glm::mat4 projectionMatrix = glm::ortho(
        -WINDOW_WIDTH / 2.f, //left
        WINDOW_WIDTH / 2.f, //right
        -WINDOW_HEIGHT / 2.f, //bot
        WINDOW_HEIGHT / 2.f, //top
        -400.f, //z near
        400.f);  //z far

    PhysicsWorld pWorld = PhysicsWorld();
    DragForceGenerator drag = DragForceGenerator();

    using clock = std::chrono::high_resolution_clock;
    auto curr_time = clock::now();
    auto prev_time = curr_time;
    std::chrono::nanoseconds curr_ns(0);
    std::chrono::nanoseconds life(0);

    std::vector<RenderParticle*> vecRenderParticle;

    P6Particle* particle1 = new P6Particle();
    particle1->position = MyVector(-300, 150, 0);
    particle1->mass = 10.f; // 1KG
    particle1->AddForce(MyVector(0, -10, 0) * 0.0f); // Apply some initial force
    particle1->lifespan = 1000.f;
    pWorld.forceRegistry.Add(particle1, &drag);
    pWorld.AddParticle(particle1);

    GLfloat red[] = { 1,0,0,1 };

    float scale = 50.f;

    Object* obj1 = new Object(red, shader);
    obj1->scale_x = scale;
    obj1->scale_y = scale;
    obj1->scale_z = scale;

    RenderParticle* renderParticle1 = new RenderParticle(particle1, obj1);
    renderParticle1->scale = glm::vec3(particle1->radius, particle1->radius, particle1->radius);
    vecRenderParticle.push_back(renderParticle1);

    P6Particle* particle2 = new P6Particle();
    particle2->position = MyVector(300, 150, 0);
    particle2->mass = 1.f; // 1KG
    particle2->AddForce(MyVector(10, 0, 0) * 0.0f); // Apply some initial force
    particle2->lifespan = 1000.f;
    pWorld.forceRegistry.Add(particle2, &drag);
    pWorld.AddParticle(particle2);

    GLfloat blue[] = { 0,0,1,1 };

    Object* obj2 = new Object(blue, shader);
    obj2->scale_x = scale;
    obj2->scale_y = scale;
    obj2->scale_z = scale;

    RenderParticle* renderParticle2 = new RenderParticle(particle2, obj2);
    renderParticle2->scale = glm::vec3(particle2->radius, particle2->radius, particle2->radius);
    vecRenderParticle.push_back(renderParticle2);

    Bungee* bungee = new Bungee();
    pWorld.forceRegistry.Add(particle1, bungee);

    Chain* chain = new Chain();
    pWorld.forceRegistry.Add(particle2, chain);

    RenderLine* line1 = new RenderLine(bungee->getanchorPoint(), particle1->position, MyVector(1, 1, 1));

    RenderLine* line2 = new RenderLine(chain->getanchorPoint(), particle2->position, MyVector(1, 1, 1));

    while (!glfwWindowShouldClose(window))
    {
        // Get the current time
        curr_time = clock::now();
        // Check the duration in between the last iteration
        auto dur = std::chrono::duration_cast<std::chrono::nanoseconds>(curr_time - prev_time);
        // Set prev with the current for the next iteration
        prev_time = curr_time;

        curr_ns += dur;
        life += dur;

        if (curr_ns >= timestep)
        {
            auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(curr_ns);
            auto life1 = std::chrono::duration_cast<std::chrono::milliseconds>(life);

            curr_ns -= timestep;

            // Convert ms to seconds
            pWorld.Update((float)ms.count() / 1000);

            for (std::vector<RenderParticle*>::iterator i = vecRenderParticle.begin(); i != vecRenderParticle.end();) {
                (*i)->getParticle()->CheckLife((float)life1.count() / 1000);             

                if ((*i)->getParticle()->IsDestroyed()) {
                    i = vecRenderParticle.erase(i);
                }
                else {
                    i++;
                }
            }
        }

        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT);
        glBindVertexArray(VAO);

        for (RenderParticle* particle : vecRenderParticle) {
            line1->Update(bungee->getanchorPoint(), particle1->position, projectionMatrix);
            line1->Draw();

            line2->Update(chain->getanchorPoint(), particle2->position, projectionMatrix);
            line2->Draw();

            particle->Draw();

            shader->setMat4("projection", 1, projectionMatrix);

            glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }


    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    char a;
    std::cout << "Enter any character to exit. . ." << std::endl;
    std::cin >> a;
    glfwTerminate();



    return 0;
}